from functools import partial, wraps
import os
import time
import threading
import traceback
import sys
import ntpath
from collections.abc import Mapping
from os.path import join, dirname, basename, splitext, exists
import pandas
from six import iteritems
import glob
from docplex.util.environment import get_environment
import json

output_lock = threading.Lock()

def set_stop_callback(cb):
    env = get_environment()
    env.abort_callbacks += [cb]
    
class _InputDict(dict):
    def __init__(self, directory, names):
        dict.__init__(self)
        self._directory = directory
        for k in names:
            dict.__setitem__(self, k, None)
        file='model_schema.json'
        if self._directory is not None:
            file  = "{0}/".format(self._directory) + file
        self.dtype_schemas = self.get_dtype_schemas( file)
    def __getitem__(self, key):
        if isinstance(key, str):
            item = dict.__getitem__(self, key)
            if item is None:
                file = "{0}.csv".format(key)
                if file in self.dtype_schemas:
                    return self.read_df( key, dtype=self.dtype_schemas[file])
                else:
                    return self.read_df( key)
            else:
                return item
        else:
            raise Exception("Accessing input dict via non string index")
    def read_df(self, key, **kwargs):
        env = get_environment()
        file = "{0}.csv".format(key)
        if self._directory is not None:
            file  = "{0}/".format(self._directory) + file
        with env.get_input_stream(file) as ist:
            params = {'encoding': 'utf8'}
            if kwargs:
                params.update(kwargs)
            df = pandas.read_csv( ist, **params)
            dict.__setitem__(self, key, df)
        return df
    def get_dtype_schemas(self, path):
        dtype_schemas = {}
        if exists(path):
            input_schemas=json.load(open(path))
            if 'input' in input_schemas:
                for input_schema in input_schemas['input']:
                    dtype_schema = {}
                    if 'fields' in input_schema:
                        for input_schema_field in input_schema['fields']:
                            if input_schema_field['type']=='string':
                                dtype_schema[input_schema_field['name']]='str'
                        if len(dtype_schema) > 0:
                            dtype_schemas[input_schema['id']]=dtype_schema
        print(dtype_schemas)
        return dtype_schemas

class _LazyDict(Mapping):
    def __init__(self, *args, **kw):
        self._raw_dict = _InputDict(*args, **kw)

    def __getitem__(self, key):
        return self._raw_dict.__getitem__(key)

    def __iter__(self):
        return iter(self._raw_dict)

    def __len__(self):
        return len(self._raw_dict)

    def read_df(self, key, **kwargs):
        return self._raw_dict.read_df(key, **kwargs)

def get_all_inputs(directory=None):
    '''Utility method to read a list of files and return a tuple with all
    read data frames.
    Returns:
        a map { datasetname: data frame }
    '''

    all_csv = "*.csv"
    g = join(directory, all_csv) if directory else all_csv

    names = [splitext(basename(f))[0] for f in glob.glob(g)]
    result = _LazyDict(directory, names)
    return result


def callonce(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not wrapper.called:
            wrapper.called = True
            return f(*args, **kwargs)
    wrapper.called = False
    return wrapper


@callonce
def write_all_outputs(outputs):
    '''Write all dataframes in ``outputs`` as .csv.
    Args:
        outputs: The map of outputs 'outputname' -> 'output df'
    '''
    global output_lock
    with output_lock:
        for (name, df) in iteritems(outputs):
            csv_file = '%s.csv' % name
            print(csv_file)
            with get_environment().get_output_stream(csv_file) as fp:
                if sys.version_info[0] < 3:
                    fp.write(df.to_csv(index=False, encoding='utf8'))
                else:
                    fp.write(df.to_csv(index=False).encode(encoding='utf8'))
    if len(outputs) == 0:
        print("Warning: no outputs written")


def wait_and_save_all_cb(outputs):
    global output_lock
    # just wait for the output_lock to be available
    t = time.time()
    with output_lock:
        pass
    elapsed = time.time() - t
    # write outputs
    write_all_outputs(outputs)


def get_line_of_model(n):
    env = get_environment()
    with env.get_input_stream('model.py') as m:
        lines = m.readlines()
        return lines[n - 1].decode("utf-8")


class InterpreterError(Exception):
    pass

if __name__ == '__main__':
    inputs = get_all_inputs()
    outputs = {}
    set_stop_callback(partial(wait_and_save_all_cb, outputs))
    
    env = get_environment()
    # The IS_DODS env must be True for model.py if running in DODS
    os.environ['IS_DODS'] = 'True'
    # This allows docplex.mp to behave the same (publish kpis.csv and solution.json
    # if this script is run locally
    os.environ['DOCPLEX_CONTEXT'] = 'solver.auto_publish=True'
    with env.get_input_stream('model.py') as m:
        try:
            exec(m.read().decode('utf-8'), globals())
        except SyntaxError as err:
            error_class = err.__class__.__name__
            detail = err.args[0]
            line_number = err.lineno
            fileName = ntpath.basename(err.filename)
            # When the error occurs in model.py, there is no err.filename
            if fileName == "<string>":
                fileName = "model.py"
            imsg = '\nFile "' + fileName + '", line %s\n' % line_number
            if err.text != None:
                imsg += err.text.rstrip() + '\n'
                spaces = ' ' * (err.offset - 1) if err.offset > 1 else ''
                imsg += spaces + "^\n"
            imsg += '%s: %s\n' % (error_class, detail)
            sys.tracebacklimit = 0
            raise InterpreterError(imsg)
        except Exception as err:
            error_class = err.__class__.__name__
            detail = ""
            if(len(err.args) > 0):
                detail = err.args[0]
            cl, exc, tb = sys.exc_info()
            ttb = traceback.extract_tb(tb)
            if(len(ttb) > 1):
                for i in range(len(ttb)):
                    fileName = ntpath.basename(ttb[i][0])
                    line = ttb[i][3]
                    if(fileName == "<string>"):
                        line = get_line_of_model(ttb[i][1])
                        ttb[i] = ("model.py", ttb[i][1], ttb[i][2], line)
                    elif( ntpath.dirname(ntpath.abspath(ttb[i][0])) == ntpath.abspath(".") ):
                        ttb[i] = (fileName, ttb[i][1], ttb[i][2], line)
                    else:
                    	ttb[i] = (ttb[i][0], ttb[i][1], ttb[i][2], line)
                ttb = ttb[1:]
            s = traceback.format_list(ttb)
            imsg = '\n' + (''.join(s))
            imsg += '%s: %s\n' % (error_class, detail)
            sys.tracebacklimit = 0
            raise InterpreterError(imsg)
        else:
            write_all_outputs(outputs)